package Sample;

import java.util.ArrayList;

/**
 * Created by woden on 7/11/2016.
 */
public class School {


    private String schoolName;



    School (String schoolName)
    {
        this.schoolName = schoolName;
    }


    public String getSchoolName() {
        return schoolName;
    }





    /*
    ArrayList<Professor>professor;



    private String [] subject;


    private String name;

    private boolean atrType [];














    public void setProfessor(ArrayList<Professor> professor) {
        this.professor = professor;
    }

    public ArrayList<Professor> getProfessor() {
        return professor;
    }






    public void getDay(){
    System.out.println (
            "Mon="+mon+
                    " Tue="+tue+
                    " Wen="+wen+
                    " Thu="+thu+
                    " Fri="+fri+
                    " Sat="+sat+
                    " Sun="+sun
    );
}








    public String getName() {
        return name;
    }




    */
}
