package Sample;

import java.util.List;

/**
 * Created by woden on 7/11/2016.
 */
public class Professor {

    private int iD;         // Professor's ID
    private String friName;
    private String lasName;
  //  private List<Professor> courseList;


    Professor (int iD, String friName, String lasName)
    {
        this.iD = iD;
        this.friName = friName;
        this.lasName = lasName;
    }



//public addCouse (Course couse);

    public int getiD () // Returns professor's ID
    {
        return iD;
    }
    public String getName () // Returns professor's name
    {
        String fullName = friName+lasName;
        return fullName;
    }



    // Returns reference to list of classes that professor teaches

/*

   public List<Course>   getCourse()
   {
      return _courseList;
    }
*/


}
