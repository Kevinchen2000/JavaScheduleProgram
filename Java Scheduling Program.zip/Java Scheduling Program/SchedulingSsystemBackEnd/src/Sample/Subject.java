package Sample;

import java.util.ArrayList;

/**
 * Created by woden on 7/17/2016.
 */
/*
Subject class can associated with building and classes or non associated with.
Subject class is set to read only
*/


public class Subject {
        /*
    private String subjectName;
    ArrayList<ClassC>classList = new ArrayList<>(); //Store associated class object
    ArrayList<Building>buildingList = new ArrayList<>(); //Store associated building object

    Subject (String subjectName)
    {   this.subjectName=subjectName; }


    public String getSubjectName()
    { return subjectName; }


    public void initializeSubject (){ //remove all class and building objects
        classList.clear();
        buildingList.clear();
    }

    //--------------------Associated with Class------------------------------------------------------------------------

    public int getNumberOfClass ()
    { return classList.size();}

    public ArrayList<ClassC> getClassList() {
        return classList;
    }

    public void dropClass(ClassC targetClass){ //Only call from ClassC class
        classList.remove(targetClass);
    }

    //--------------------Associated with Building------------------------------------------------------------------------
    //1 building or no more then 2 buildings
    public ArrayList<Building> getBuildingList ()
    {  return buildingList;    }

    public int getNumberOfBuilding ()
    { return buildingList.size();}

    public void dropBuilding(Building targetBuilding){ //Only call from Building class
        buildingList.remove(targetBuilding);
        */
    }


