package Sample;

/**
 * Created by woden on 7/11/2016.
 */
public class Course {

    private String courseName;
   // private ArrayList<Student> stuArr = new ArrayList<>();

    private Professor professor; //Only one professor allow
    private ClassC classC; //Only one class allow

    private int iD;
    private String name;


    private int seat;

    private float timeStr;
    private  float timeEnd;


    //get proferssor, class, courseName
    public void dropProfessor () {} //drop professor object//delete course object from professor courseList
    public void dropClass() {} //drop class object
    public void initializeCourse() {}//




/*
    //private  int duration;

    // Initializes course
    public Course (Professor professor, ClassC classCm, int iD,
                                String name, String subject, int seat, float timeStr, float timeEnd
                                    )
    {
        this.professor=professor;
        this.classC=classC;
        this.iD=iD;
        this.name=name;
        this.subject=subject;
        this.seat=seat;
        this.timeStr=timeStr;
        this.timeEnd=timeEnd;
    }




    public int getiD () // Returns course ID
    { return iD;}

public String getName () // Returns course name
{return name;}

    // Returns TRUE if another class has same professor.


public Professor getProfessor() { // Return pointer to professor who teaches
    return professor;
}

    public ClassC  getClassC()  // Return pointer to class to which course belongs
    {
        return classC;
    }

public int getSeat (){// Returns number of seats (course) required in room
    return  seat;
}

   // public boolean isLabRequire()
    {
  //      return lab;
    }
*/


}
