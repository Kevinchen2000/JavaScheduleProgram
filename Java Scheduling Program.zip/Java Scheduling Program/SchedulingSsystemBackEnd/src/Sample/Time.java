package Sample;

/**
 * Created by woden on 7/15/2016.
 */
public class Time {

    //Week day
    private boolean mon;
    private boolean tue;
    private boolean wen;
    private boolean thu;
    private boolean fri;
    private boolean sat;
    private boolean sun;
     final private boolean  weekDay []=new boolean [7];

    private float dayTimeStr;
    private float dayTimeEnd;

    private float totalDayTime;
    private float totalWeekTime;
    private int avaDay;

  //Constructor---------------------------------------------

    Time ()  //set different time for week day
    {}

    Time (boolean mon, boolean tue, boolean wen, boolean thu, boolean fri, boolean sat, boolean sun)//set week time
    {
        this.mon=mon;
        this.tue=tue;
        this.wen=wen;
        this.thu=thu;
        this.fri=fri;
        this.sat=sat;
        this.sun=sun;
    }

    Time (float dayTimeStr, float dayTimeEnd)//set day time
    {
        this.dayTimeStr = dayTimeStr;
        this.dayTimeEnd=dayTimeEnd;
    }


    public float getTotalDayTime()
    {
        totalDayTime = dayTimeEnd-dayTimeStr;
        return totalDayTime;
    }



    public float getTotalWeekTime()
    {
        weekDay[0]=mon;
        weekDay[0]=tue;
        weekDay[0]=wen;
        weekDay[0]=thu;
        weekDay[0]=fri;
        weekDay[0]=sat;
        weekDay[0]=sun;

       for (int i =0; i<7; i++)
       {
           if (weekDay[i]==true)
           {
               totalWeekTime=totalWeekTime+getTotalDayTime();
           }
       }
        return  totalWeekTime;
    }






}
