package Sample;

/**
 * Created by woden on 7/11/2016.
 */
public class ClassC {

    private Subject subject;
    private String name;
    private int duration;
   // private boolean lab;

    /*
    private boolean property1;
    private boolean property2;
    private boolean property3;
    private boolean property4;
    private boolean property5;
    */
    public ClassC () {}


    public ClassC (String name)
    {this.name=name;}


    public ClassC (String name, Subject subject) {
        this.name = name;
    //    this.subject = subject;
    }



    public String getClassName() {
        return name;
    }

    public void removeSubject() {
        subject = null;
   //     subject.dropClass(ClassC.this); //delete class object in Subject classList
    }


    public Subject getSubject() {
        return subject;
    }

    public int getDuration() {
        return duration;
    }
}
