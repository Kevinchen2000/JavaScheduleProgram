package algorithm;

/**
 * Created by woden on 7/17/2016.
 */
public class Course {
    /*
 private boolean property1;
 private boolean property2;
 private boolean property3;
 private boolean property4;
 private boolean property5;
 */
    private String name;
    private Professor professor;
    private ClassC classC;
    private boolean lab;
    private int seat;


    Course (String name, Professor professor, ClassC classC, int seat)
    {
        this.name=name;
        this.professor=professor;
        this.classC=classC;
        this.seat=seat;
        this.professor.setCourses(Course.this); //add Course object to Professor courseList
    }


    public void setLab(boolean lab) {
        this.lab = lab;
    }

    public boolean getLab() {return lab;}

    public String getName() {
        return name;
    }

    public Professor getProfessor() {
        return professor;
    }

    public ClassC getClassC() {
        return classC;
    }

    public int getSeat() {
        return seat;
    }
}
