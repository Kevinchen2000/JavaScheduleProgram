package algorithm;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by woden on 7/17/2016.
 */
public class Test {

    public static void main (String arg []) {

        Building tech = new Building("TECH");
        Building adm = new Building("ADM");
        Building ssb = new Building("SSB");

        Room room1 = new Room(101, 25, true);
        Room room2 = new Room(102, 35, false);
        Room room3 = new Room(103, 25, false);
        Room room4 = new Room(104, 20, false);
        Room room5 = new Room(105, 25, true);

        tech.setSubject("Computer Science");
        tech.setRoom(room1);
        tech.setRoom(room2);
        tech.setRoom(room3);

        adm.setSubject("Math");
        adm.setSubject("Biology");
        adm.setRoom(room1);
        adm.setRoom(room2);
        adm.setRoom(room3);
        adm.setRoom(room4);
        adm.setRoom(room5);

        ssb.setSubject("Social Science");
        ssb.setRoom(room1);
        ssb.setRoom(room3);
        ssb.setRoom(room5);

        ArrayList<Room>roomObj=adm.getRoom();
        for(int i=0; i<adm.getNumOfRoom();i++)
System.out.print( roomObj.get(i).getRoomNum()+" ");


    Professor professor1 = new Professor("Steve", "Job");
    Professor professor2 = new Professor("Kevin", "Chen");
    Professor professor3 = new Professor("Bill", "Gate");

    ClassC classC1 = new ClassC("Java I","Computer Science",2);
    ClassC classC2 = new ClassC("HumanBody","Biology",4);
    ClassC classC3 = new ClassC("Algebra","Math",3);


    Course course1 = new Course("Programing101", professor1,classC1,25);
    Course course2 = new Course("Biology103", professor2,classC2,30);
    Course course3 = new Course("Algebra108", professor3,classC3,25);


        course1.setLab(false);

        System.out.println("-----------------------------------");
    System.out.print(course1.getName()+" "+course1.getLab()+" "+course1.getClassC().getSubject());


        System.out.println("-----------------------------------");






    }
}
