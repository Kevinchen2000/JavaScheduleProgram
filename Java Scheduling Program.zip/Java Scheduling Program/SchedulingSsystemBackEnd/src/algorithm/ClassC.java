package algorithm;

/**
 * Created by woden on 7/17/2016.
 */
public class ClassC {

    private String name;
    private String subject;
    private int duration;


    public ClassC() {
    }

    /*
    public ClassC(String name) {
        this.name = name;}

    public ClassC(String name, String subject) {
        this.name = name;
        this.subject = subject;}
     */

    public ClassC(String name, String subject, int duration) {
        this.name = name;
        this.subject = subject;
        this.duration=duration;}



    public String getName() {
        return name;}

    public String getSubject() {
        return subject;}

    public int getDuration() {
        return duration;}

    public void initialize (){
        name="";
        subject="";
        duration=0;
    }







}
