package algorithm;

import java.util.*;

/**
 * Created by woden on 7/18/2016.
 */
public class Schedule {
    // Number of crossover points of parent's class tables
    private int numberOfCrossoverPoints;

    // Number of classes that is moved randomly by single mutation operation
    private int mutationSize;

    // Probability that crossover will occure
    private int crossoverProbability;

    // Probability that mutation will occure
    private int mutationProbability;

    // Fitness value of chromosome
    private float fitness;

    // Flags of class requiroments satisfaction
    private Deque<Boolean> criteria;

    // Time-space slots, one entry represent one hour in one classroom
    private Deque<List<Course>>slot;

    // Class table for chromosome
    // Used to determine first time-space slot used by class
    /* K - the type of keys maintained by this map
       V - the type of mapped values   <K, V> */
    private HashMap<Integer,Course>courses;
































}
