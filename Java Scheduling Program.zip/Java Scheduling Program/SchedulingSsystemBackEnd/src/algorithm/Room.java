package algorithm;

/**
 * Created by Kevin Chen on 7/17/2016.
 * Room (depend on) Building Composition
 *
 */
public class Room {

    private Building building;
    private int roomNum;
    private int seat;
    private boolean lab;

    /*
    private boolean property1;
    private boolean property2;
    private boolean property3;
    private boolean property4;
    private boolean property5;
    */
    Room ( int roomID,  int seat, boolean lab)
    {
        this.roomNum=roomID;
        this.seat=seat;
        this.lab=lab;
    }

    Room (Building building, int roomNum,  int seat, boolean lab)
    {
        this.building=building;
        this.roomNum=roomNum;
        this.seat=seat;
        this.lab=lab;
    }


    public Building getBuilding() {
        return building;
    }

    public boolean getLab(){
        return lab;
    }

    public int getRoomNum() {
        return roomNum;
    }

    public int getSeat() {
        return seat;
    }
}
