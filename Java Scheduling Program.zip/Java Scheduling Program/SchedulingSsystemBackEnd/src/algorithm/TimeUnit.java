package algorithm;

/**
 * Created by woden on 7/18/2016.
 */
public enum TimeUnit {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY,
    THURSDAY, FRIDAY, SATURDAY;
}
