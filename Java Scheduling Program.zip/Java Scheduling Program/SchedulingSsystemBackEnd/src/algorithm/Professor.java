package algorithm;

import java.util.ArrayList;

/**
 * Created by woden on 7/17/2016.
 */
public class Professor {

    private String friName;
    private String lasName;
    private String name;
    private ArrayList<Course>courses = new ArrayList<>();

    Professor (String friName, String lasName)
    {
        this.friName = friName;
        this.lasName = lasName;
    }

    public void setCourses(Course targetCourse) { //Only access by Course constructor
        courses.add(targetCourse);
    }

    public void clearCourse(){
        courses.clear();
    }

    public String getName() {
        return name = friName+lasName;
    }



}
