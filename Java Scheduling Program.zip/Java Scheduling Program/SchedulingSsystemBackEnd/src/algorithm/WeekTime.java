package algorithm;

/**
 * Created by woden on 7/18/2016.
 */
public class WeekTime {
    private float dayTimeStr;
    private float dayTimeEnd;
    private DayTime dayTime;


    //Week day
    private boolean mon;
    private boolean tue;
    private boolean wen;
    private boolean thu;
    private boolean fri;
    private boolean sat;
    private boolean sun;


    WeekTime () {}


    public void setMon(boolean mon, DayTime dayTime ) {
        this.mon = mon;
    }



    public void setThu(boolean tue) {
        this.tue = tue;
    }
}
