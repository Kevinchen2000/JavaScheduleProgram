package algorithm;

/**
 * Created by woden on 7/18/2016.
 */
public class DayTime {

    private float dayTimeStr;
    private float dayTimeEnd;



    //Week day
    private boolean mon;
    private boolean tue;
    private boolean wen;
    private boolean thu;
    private boolean fri;
    private boolean sat;
    private boolean sun;


    DayTime (float dayTimeStr, float dayTimeEnd)
    {
        this.dayTimeStr=dayTimeStr;
        this.dayTimeEnd=dayTimeEnd;
    }



    public void setMon(boolean mon ) {
        this.mon = mon;
    }

    public void setThu(boolean tue) {
        this.tue = tue;
    }
}
