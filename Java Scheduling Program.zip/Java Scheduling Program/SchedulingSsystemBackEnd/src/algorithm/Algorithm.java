package algorithm;

import java.util.Deque;
import java.util.Queue;

/**
 * Created by woden on 7/18/2016.
 */
public class Algorithm {

    // Population of chromosomes
    Queue<Schedule> chromosomes;

    // Inidicates wheahter chromosome belongs to best chromosome group
    Queue<Boolean> _bestFlags;

    // Indices of best chromosomes
    Queue<Integer> _bestChromosomes;

    // Number of best chromosomes currently saved in best chromosome group
    int currentBestSize;

    // Number of chromosomes which are replaced in each generation by offspring
    int replaceByGeneration;


}
