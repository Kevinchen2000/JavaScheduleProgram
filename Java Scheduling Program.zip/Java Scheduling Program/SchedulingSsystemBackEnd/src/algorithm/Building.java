package algorithm;

import java.util.ArrayList;
import java.util.StringJoiner;

/**
 * Created by KevinChen on 7/17/2016.
 * Building (has many) Room //Aggregation
 * Building has many subject
 */
public class Building {

    private String buildingName;
    private ArrayList<String>subject=new ArrayList<>();
    private ArrayList<Room> room = new ArrayList<>();

    private int numOfRoom;


    Building(String buildingName)
    {this.buildingName=buildingName;}


    public void setSubject(String targetSubject) {
        subject.add(targetSubject);
    }

    public ArrayList<String> getSubject () {
        return subject;
    }

    public void setRoom(Room room) { //Add room to Building
        this.room.add(room);
    }

    public int getNumOfRoom() {
        numOfRoom=room.size();
        return numOfRoom;
    }

    public ArrayList<Room> getRoom() {
        return room;
    }

    public String getBuildingName() {
        return buildingName;
    }



}


